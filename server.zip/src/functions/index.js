module.exports = {
  Google: require("./components/googleMapsScraper"),
  YellowScraper: require("./components/yellowPageScraper"),
  Pappers: require("./components/pappersScraper"),
  InseeSiren: require("./components/inseeSirenScraper"),
};
