module.exports = {
  serverMessage: require("./components/serverMessage"),
  ...require("./components/uploadFile"),
};
