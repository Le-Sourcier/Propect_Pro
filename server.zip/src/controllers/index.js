module.exports = {
  ...require("./components/enrichsmentController"),
  ...require("./components/jobsController"),
  ...require("./components/userController"),
};
